var express = require('express');
var app = express();
var url = require('url');
var redis = require("redis");
var redisURL = url.parse(process.env.REDIS_URL);
var client = redis.createClient(redisURL.port, redisURL.hostname);
client.auth(redisURL.auth.split(":")[1]);

app.set('port', (process.env.PORT || 5000));

app.use(express.static(__dirname + '/public'));

// views is directory for all template files
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

    
app.get('/', function (req, res) {
  res.send('Roblo External Data Server');
});

app.get('/get', function(req, res) {
  if (req.query.key != null) {
    client.get(req.query.key, function (err, reply) {
      if (reply != null) {
        reply = {
            result: "success",
            value: reply
        };
        res.send(JSON.stringify(reply));
      } else {
        reply = {
            result: "error",
        };
        res.send(JSON.stringify(reply));
      }
    });
  }else {
    var reply = {
      result: "error",
    };
    res.send(JSON.stringify(reply));

  }
});

app.get('/set', function(req, res) {

   if (req.query.key != null && req.query.value != null) {
      client.set(req.query.key, req.query.value);
      var reply = {
        result: "success",
      };
      res.send(JSON.stringify(reply));
   }else {
    var reply = {
      result: "error"
    };
    res.send(JSON.stringify(reply));
   }
});


app.listen(app.get('port'), function() {
  console.log('Node app is running on port', app.get('port'));
});
