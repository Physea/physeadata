local Players            	= game:GetService("Players")
local ReplicatedStorage  	= game:GetService("ReplicatedStorage")
local ServerStorage  		= game:GetService("ServerStorage")
local ServerScriptService	= game:GetService("ServerScriptService")
local StarterGui         	= game:GetService("StarterGui")
local RunService         	= game:GetService("RunService")
local HttpService 			= game:GetService('HttpService')

local cacheLength = 10 --seconds
local urlBase = "https://YOURURL.herokuapp.com/"
local dataCache = {}

function decodeJson(json)
	local jsonTab = {} pcall(function ()
	jsonTab = HttpService:JSONDecode(json)
	end) return jsonTab
end

function encodeJson(data)
	local jsonString = data pcall(function ()
	jsonString = HttpService:JSONEncode(data)
	end) return jsonString
end

function doGet(key)
	local json = HttpService:GetAsync(urlBase.."get?key="..key)
	local data = decodeJson(json)
	if data.result == "success" then
		return decodeJson(data.value)
	else
		warn("Database error:", data.error)
		return
	end
end

function doPut(key, data)
	local json = HttpService:UrlEncode(encodeJson(data))
	local retJson = HttpService:GetAsync(urlBase.."set?key="..key.."&value="..json)	
	local data = decodeJson(retJson)
	if data.result == "success" then
		return true
	else
		warn("Database error:", data.error)
		return false
	end
end

function doCacheGet(key)
	local data = dataCache[key]
	if not data then
		local newData = doGet(key)
		dataCache[key] = {
			CacheTime = time(),
			Value = newData
		}
		return newData
	else
		if time() - data.CacheTime > cacheLength then
			local newData = doGet(key)
			data.Value = newData
			data.CacheTime = time()
			return newData
		else
			return data.Value
		end
	end
end

function doHardGet(key)
	local data = dataCache[key]
	if not data then
		local newData = doGet(key)
		dataCache[key] = {
			CacheTime = time(),
			Value = newData
		}
		return newData
	else
		local newData = doGet(key)
		data.Value = newData
		data.CacheTime = time()
		return newData
	end
	
end

local database = {}
function database:PostAsync(key, value)
	return doPut(key, value)
end
function database:GetAsync(key)
	return doCacheGet(key)
end
function database:HardGetAsync(key)
	return doHardGet(key)
end	
return database

